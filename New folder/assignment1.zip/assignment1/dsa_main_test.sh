clear
echo "###################################################################################"
echo "##############              GRADING ASSINMENT1 OF DSA               ###############"
echo "##############             (unittest for C++: doctest)              ###############"
echo "###################################################################################"

echo "[1] removing previous output ..."
rm -f ./dsacpp/assignment1

echo "[2] building DSACPP, please wait ..."
g++ ./dsacpp/assignment1.cpp ./dsacpp/src/geom/*.cpp -I ./dsacpp/include -I ./doctest -o assignment1

echo "###################################################################################"
echo "[3] running the test ..."
echo "\n"
./assignment1
echo "\n"
