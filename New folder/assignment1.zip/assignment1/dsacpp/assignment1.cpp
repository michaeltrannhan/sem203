#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "testassignments/DLinkedListTestASSIGN.h"
#include "testassignments/SLinkedListTestASSIGN.h"
#include "testassignments/XArrayListTestASSIGN.h"
#include "testassignments/StackTestASSIGN.h"
#include "testassignments/QueueTestASSIGN.h"
