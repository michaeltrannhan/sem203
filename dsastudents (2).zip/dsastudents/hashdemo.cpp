#include <iostream>
#include <hash/IMap.h>
#include <hash/XHashMap.h>
#include <hash/XHashMapDemo.h>
using namespace std;

int main(){
    XHashMap<int, int> map(&XHashMap<int, int>::simpleHash);
    int keys[]      = {2,  12, 42,  72, 3,  45, 76, 30};
        int values[]    = {35, 67, 100, 23, 68, 68, 72, 45};
        for(int idx=0; idx < 8; idx++){
            map.put(keys[idx], values[idx]);
        }
        map.remove(2);
        map.println();
        //
        /*
        for(int idx=0; idx < 8; idx++){
            cout << " contains key" << map.containsKey(keys[idx]) << endl;
            cout << " contains value " << map.containsValue(values[idx]) << endl;
        }
        
        cout << "contains key" << map.containsKey(1000) << endl;
        cout << "contains value" << map.containsValue(1000) << endl;
        */
}