#include <iostream>
#include <sorting/BubbleSort.h>
#include <sorting/ISort.h>
#include <util/sampleFunc.h>
#include <sorting/BubbleSortDemo.h>
#include <sorting/ShellSort.h>
#include <sorting/StraightInsertionSort.h>
#include <sorting/StraightInsertionSortDemo.h>
#include <sorting/ShellSortDemo.h>
#include <sorting/HeapSortDemo.h>
#include <heap/Heap.h>
#include <heap/IHeap.h>
#include <sorting/StraightSelectionSort.h>
#include <sorting/StraightSelectionSortDemo.h>
#include <sorting/DLinkedListSE.h>
#include <list/DLinkedList.h>
#include <list/IList.h>
#include <util/ArrayLib.h>
#include <util/Point.h>
#include <sorting/QuickSort.h>
#include <sorting/QuickSortDemo.h>
using namespace std;

int main()
{
    //BuubleSortDemo1();
    // int arr[] ={9,7,5,1,11,4,100};
    // BubbleSort<int> b;
    // b.sort(arr, 7, &SortSimpleOrder<int>::compare4Ascending);
    // for(int idx=0; idx < 7; idx++){
    //     cout << arr[idx] << ", ";
    // }
    //HeapSortDemo1();
    // int arr[] = {45, 97, 12, 2, 39, 3, 37, 87};
    // Heap<int> heap;
    // int size =8;
    // heap.heapify(arr, size);
    // int arr1[8];
    // for(int i = 0;i < 8; i ++){
    //     arr1[i] = heap.pop();
    //     heap.heapify(arr,size-i-1);
    // }
    // for(int i = 0; i < 8; i++){
    //     cout << arr1[i] << endl;
    // }

    //straightSelDemo1();

    // int shell_segments[] = {1, 3, 7};
    // ISort<int> *pAlgorithm[] = {
    //     new StraightInsertionSort<int>(),
    //     new ShellSort<int>(shell_segments, 3),
    //     new StraightSelectionSort<int>(),
    //     new BubbleSort<int>(),
    //     new HeapSort<int>(),
    //     new QuickSort<int>()};
    // for (int algIdx = 0; algIdx < 6; algIdx++)
    // {
    //     cout << algIdx << endl;
    //     int count = 1000;
    //     int *values = genIntArray(count, 0, 999999);

    //     pAlgorithm[algIdx]->sort(values, count, &SortSimpleOrder<int>::compare4Desending);
    //     //for(int i = 0; i < count; i++) cout << values[i]<< "->";
    //     //Then check values: descending

    //     cout << isOrdered(values, count, false) << endl;
    //             cout << endl;
    //     delete[] values;
    // }
    // HeapSort<int> heap;
    // int count = 100;
    // int *values = genIntArray(count, 0, 99999);
    // heap.sort(values, count, &SortSimpleOrder<int>::compare4Ascending);
    // //for(int i = 0;i< count; i ++) cout << values[i] << "->";

    // for(int i = 0; i < count; i ++) {
    //     cout << i << endl;
    //     if(values[i] > values[i+1]) break;
    // }
    //cout << isOrdered(values, count, false) << endl;

    Heap<int> heap;
    int count = 100000;
    int *values = genIntArray(count, 0, 999999);
    heap.heapify(values, count);

    //heap.println();
    cout << endl;
    int *temp = new int[count];
    for (int i = 0; i < count; i++)
    {
        //temp[i] = heap.pop();
        values[i] = heap.pop();
    }

    for (int i = 0; i < count; i++)
    {
        //cout << temp[i] << endl;
        cout << values[i] << endl;
    }
    delete []values;
    cout << "---------------" << endl;
    cout << isOrdered(temp, count, true)<< endl;

    return 0;
}