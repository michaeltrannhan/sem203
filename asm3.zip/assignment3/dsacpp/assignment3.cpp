#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "testassignments/HeapTestASSIGN.h"
#include "testassignments/XHashMapTestASSIGN.h"
#include "testassignments/SortTestASSIGN.h"
