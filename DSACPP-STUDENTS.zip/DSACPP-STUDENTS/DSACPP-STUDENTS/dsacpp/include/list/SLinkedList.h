#ifndef SLINKEDLIST_H
#define SLINKEDLIST_H
#include "list/IList.h"

template<class T>
class SLinkedList : public IList<T>{
private:

public:
    
}